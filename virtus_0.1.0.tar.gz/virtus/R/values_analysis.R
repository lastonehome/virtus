#' Analyze Human Values in Text
#'
#' This function analyzes a batch of texts to measure human values based on a predefined dictionary.
#' @param texts A character vector containing the texts to analyze.
#' @param dictionary_path Optional. The path to the values dictionary CSV file. If not provided, the default path will be used.
#' @param output_type The type of output: "score" (default), "percentage", or "word_percentage".
#' @return A data frame with the original texts and columns for each human value.
#' @export
analyze_values <- function(texts, dictionary_path = NULL, output_type = "score") {
  # Load the values dictionary
  dictionary <- load_values_dictionary(dictionary_path)

  # Ensure the texts are in lowercase for matching
  texts <- tolower(texts)

  # Initialize a data frame to store the results
  values <- unique(dictionary$Value)
  results <- data.frame(Text = texts, matrix(0, nrow = length(texts), ncol = length(values)))
  colnames(results)[-1] <- values

  # Calculate the score for each value
  for (i in seq_along(texts)) {
    text <- texts[i]
    for (value in values) {
      words <- dictionary[dictionary$Value == value, "Word"]
      count <- sum(sapply(words, function(word) {
        matches <- gregexpr(paste0("\\b", word, "\\b"), text, perl = TRUE)
        sum(sapply(matches, function(match) ifelse(match[1] == -1, 0, length(match))))
      }))
      results[i, value] <- count
    }

    # Calculate percentages if required
    total_score <- sum(results[i, values])
    total_words <- sum(strsplit(text, "\\W+")[[1]] != "")
    if (output_type == "percentage" && total_score > 0) {
      results[i, values] <- results[i, values] / total_score * 100
    } else if (output_type == "word_percentage" && total_words > 0) {
      results[i, values] <- results[i, values] / total_words * 100
    }
  }

  return(results)
}
